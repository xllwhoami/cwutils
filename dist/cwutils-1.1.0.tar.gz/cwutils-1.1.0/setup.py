from distutils.core import setup

setup(
	name='cwutils',
	version='1.1.0',
	description='... simple utils',
	author='Chaos and whoami.exe',
	author_email='nonono@nono.no',
	url='web.nono.no',
	install_requires = [
		'humanfriendly'
	],
	packages=['cwutils']
)