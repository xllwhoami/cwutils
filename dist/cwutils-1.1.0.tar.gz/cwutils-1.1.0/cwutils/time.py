from humanfriendly import format_timespan

def time_to_string(utime):
	return format_timespan(utime)